radius = float(input("Введіть радіус циліндра: "))
height = float(input("Введіть висоту циліндра: "))
pi = 3.14
volume = pi * radius ** 2 * height
print(f"Об'єм циліндра: {volume}")