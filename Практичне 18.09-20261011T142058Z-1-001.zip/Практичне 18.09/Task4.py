number1 = float(input("Введіть перше число: "))
number2 = float(input("Введіть друге число: "))
operator = input("Введіть оператор (+, -, *, /): ")
match operator:
    case "+":
        result = number1 + number2
        print(f"Результат: {result}")

    case "-":
        result = number1 - number2
        print(f"Результат: {result}")

    case "*":
        result = number1 * number2
        print(f"Результат: {result}")

    case "/":
        if number2 != 0:
            result = number1 / number2
            print(f"Результат: {result}")
        else:
            print("Помилка: на нуль ділити не можна")

    case _:
        print("Помилка: невідомий оператор")