money = 1000
years = 0
while money <= 2000:
    money = money + money * 0.10
    years = years + 1
print(f"Потрібно років: {years}")
print(f"Сума вкладу: {money}")