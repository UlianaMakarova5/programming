text = input("Введіть текст: ")
text = text.lower()
letters = {}
for letter in text:
    if letter.isalpha():
        if letter in letters:
            letters[letter] = letters[letter] + 1
        else:
            letters[letter] = 1
most_common_letter = ""
max_count = 0
for letter in letters:
    if letters[letter] > max_count:
        max_count = letters[letter]
        most_common_letter = letter
print("Найчастіша літера:", most_common_letter.upper())