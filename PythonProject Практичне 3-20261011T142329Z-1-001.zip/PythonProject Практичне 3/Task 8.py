data = input("Введіть числа через пробіл: ")
numbers = data.split()
for i in range(0, len(numbers) - 1, 2):
    temp = numbers[i]
    numbers[i] = numbers[i + 1]
    numbers[i + 1] = temp
print("Результат:", numbers)