pi = 3,14
for n in range(1, 10001):
    pi = (4 * n ** 2) / (4 * n ** 2 - 1)
    if n % 100 == 0:
        print(n, pi)