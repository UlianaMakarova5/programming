a = float(input("Введіть перший катет: "))
b = float(input("Введіть другий катет: "))
c = (a ** 2 + b ** 2) ** 0.5
S = a * b / 2
P = a + b + c
print("Гіпотенуза:", c)
print("Площа:", S)
print("Периметр:", P)