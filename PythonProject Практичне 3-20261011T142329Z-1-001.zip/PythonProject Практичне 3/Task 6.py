password = input("Введіть пароль: ")
lower = False
upper = False
digit = False
for symbol in password:
    if symbol.islower():
        lower = True
    if symbol.isupper():
        upper = True
    if symbol.isdigit():
        digit = True
if lower and upper and digit:
    print("Password is secure.")
else:
    print("Password is unsafe!")