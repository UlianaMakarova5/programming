n = int(input("Введіть кількість рядків: "))
k = int(input("Введіть кількість стовпців: "))
matrix = []
for i in range(n):
    row = input("Введіть елементи рядка через пробіл: ").split()
    for j in range(k):
        row[j] = float(row[j])
    matrix.append(row)
row_sums = []
for i in range(n):
    total = 0
    for j in range(k):
        total = total + matrix[i][j]
    row_sums.append(total)
column_sums = []
for j in range(k):
    total = 0
    for i in range(n):
        total = total + matrix[i][j]
    column_sums.append(total)
print("Суми рядків:", row_sums)
print("Суми стовпців:", column_sums)