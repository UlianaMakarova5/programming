data = input("Введіть числа через пробіл: ")
numbers = data.split()
for i in range(len(numbers)):
    numbers[i] = float(numbers[i])
m = len(numbers)
sum_numbers = 0
for number in numbers:
    sum_numbers = sum_numbers + number
average = sum_numbers / m
sum_squares = 0
for number in numbers:
    sum_squares = sum_squares + (number - average) ** 2
variance = sum_squares / (m - 1)
standard_deviation = variance ** 0.5
print("Середнє арифметичне:", average)
print("Дисперсія:", variance)
print("Стандартне відхилення:", standard_deviation)