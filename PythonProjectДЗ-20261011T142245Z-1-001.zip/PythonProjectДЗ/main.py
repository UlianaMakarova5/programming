contacts = {}
while True:
    command = input("Введіть команду (add, delete, search, show, exit): ")

    if command == "add":
        name = input("Введіть ім'я: ")
        number = input("Введіть номер телефону: ")
        contacts[name] = number
        print("Contact added")

    elif command == "delete":
        name = input("Введіть ім'я: ")

        if name in contacts:
            del contacts[name]
            print("Contact deleted")
        else:
            print("Not found")

    elif command == "search":
        name = input("Введіть ім'я: ")

        if name in contacts:
            print(contacts.get(name))
        else:
            print("Not found")

    elif command == "show":
        for k, v in contacts.items():
            print(f"{k}: {v}")

    elif command == "exit":
        break

    else:
        print("Unknown command")