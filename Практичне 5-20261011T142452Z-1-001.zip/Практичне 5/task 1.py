def calculate_salary(hours, hourly_rate):
    salary = hours * hourly_rate
    return salary
result = calculate_salary(36, 220)
print(result)