import random
def assign_moderator(user_list):
    moderator = random.choice(user_list)
    return moderator
employees = ["Олег", "Марія", "Іван"]
print(assign_moderator(employees))