import math
def calculate_buses(people, bus_capacity):
    buses = people / bus_capacity
    return math.ceil(buses)
print(calculate_buses(101, 67))